/*
 * Copyright (c) 2007 Mark Sangster <mark@linux-noob.com>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <iostream>
#include <string>
using namespace std;

#define PEEK_VERSION "0.1"
#define RELEASE_DATE "16 Mar 2007"

enum Type { TGZ,GZ,TBZ2,BZ2,RAR,TAR,UNK };

static const char *Notice = ("\
Copyright (c) 2007 Mark Sangster.\n\
Peek comes with ABSOLUTELY NO WARRANTY; for details type `peek -vv'.\n\
Peek is free software, and you are welcome to redistribute it\n\
under certain conditions; type `peek -vv' for details.\n");

static const char *Copyright = ("\
Copyright (c) 2007 Mark Sangster <mark@linux-noob.com>\n");

static const char *Licence = ("\
    This program is free software; you can redistribute it and/or modify\n\
    it under the terms of the GNU General Public License as published by\n\
    the Free Software Foundation; either version 2 of the License, or\n\
    (at your option) any later version.\n\
\n\
    This program is distributed in the hope that it will be useful,\n\
    but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the\n\
    GNU General Public License for more details.\n");

static const char *Obtaining = ("\
    You should have received a copy of the GNU General Public License\n\
    along with this program; if not, write to the Free Software\n\
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301,\n\
    USA.\n\
");

static const char *ReachingUs = ("\
To contact the developer, please mail to <mark@linux-noob.com>.\n");
/* To report a bug, please visit http://bugs.kutzooi.co.uk/. */

static void peek_version(void) {
	cout
		<< "Peek " << PEEK_VERSION << " (" << RELEASE_DATE << ")" << endl
		<< Notice
		<< endl;
}

static void peek_usage(void) {
	peek_version();
	cout
		<< "usage: peek <file> [<file>]" << endl
		<< "options:" << endl
		<< "  -v\t\tshow version" << endl
		<< "  -h\t\tthis help message" << endl;

	exit(0);
}


class Peek {
private:
	string fname, fext;
	int len;
	size_t flo;
	Type type;
	string command;
	
	void Process() {
		if(this->fext == "tgz")
			this->type = TGZ;
		else if(this->fext == "gz")
			if(this->findTar())
				this->type = TGZ;
			else
				this->type = GZ;
		else if(this->fext == "tbz2")
			this->type = TBZ2;
		else if(this->fext == "bz2")
			if(this->findTar())
				this->type = TBZ2;
			else
				this->type = BZ2;
		else if(this->fext == "rar")
			this->type = RAR;
		else if(this->fext == "tar")
			this->type = TAR;
		else
			this->type = UNK;
	}

	bool findTar() {
		int tmp = this->fname.find_last_of(".",this->flo-1);
		if(this->fname.substr(tmp+1,3) == "tar")
			return true;
		else
			return false;
	}
	
	void Gz() {
		this->command = "gunzip < "+this->fname;
		return;
	}

	void Bz2() {
		this->command = "bunzip2 < "+this->fname;
		return;
	}
	
	void TarGz() {
		this->Gz();
		this->fname = this->fname.substr(0,this->fname.find_last_of("."));
		this->command = this->command+" | ";
		this->Tar();
		return;
	}

	void TarBz2() {
		this->Bz2();
		this->fname = this->fname.substr(0,this->fname.find_last_of("."));
		this->command = this->command+" | ";
		this->Tar();
		return;
	}
	
	void Rar() {
		this->command = "rar l "+this->fname;
		return;
	}

	void Tar() {
		if(this->command != "")
			this->command = this->command+"tar -tvf -";
		else
			this->command = "tar -tvf "+this->fname;
		return;
	}

public:
	Peek() {
		// empty
	}

	void File(string file) {
		this->fname = file;
		this->flo = file.find_last_of(".");
		this->fext = file.substr(this->flo+1);
		this->command = "";
		this->Process();
	}

	void Show() {
		switch(this->type) {
			case TGZ:
				this->TarGz();
				break;
			case GZ:
				this->Gz();
				break;
			case TBZ2:
				this->TarBz2();
				break;
			case BZ2:
				this->Bz2();
				break;
			case RAR:
				this->Rar();
				break;
			case TAR:
				this->Tar();
				break;
			case UNK:
			default:
				cerr << "peek: Unknown file type: " << this->fname << endl;
				return;
				break;
		}
		system(this->command.c_str());
	}
};

int main(int argc, char *argv[]) {
	
	int i;
	string cur;
	Peek *peek = new Peek();

	/* check we aren't running with privileges */
	if(getegid() != getgid()) {
		cerr << "peek: I don't want privileges!" << endl;
		exit(1);
	}

	int version = 0;
	while((i = getopt(argc, argv, "hv")) != EOF)
		switch(i) {
			case 'v':
				version++;
				break;
			default:
				peek_usage();
		}

	switch(version) {
		case 0:
			break;
		case 1:
			peek_version();
			exit(0);
			break;
		case 2:
			peek_version();
			cout
				<< Copyright << endl
				<< Licence << endl
				<< Obtaining << endl
				<< ReachingUs
				<< endl;
			exit(0);
	}
	
	/* requires at least one file name */
	if(argc < 2) {
		cerr << "usage: peek <file>" << endl;
		return 1;
	}

	for(i = 1; i < argc; i++) {
		peek->File(argv[i]);
		peek->Show();
		cout << endl;
	}

	return 0;
}
