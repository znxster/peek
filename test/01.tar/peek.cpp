#include <iostream>
#include <string>
using namespace std;

enum Type { TGZ,GZ,TBZ2,BZ2,RAR,TAR,UNK };
string PROGNAME = "";

class Peek {
private:
	string fname, fext;
	int len;
	size_t flo;
	Type type;
	string command;
	
	void Process() {
		if(this->fext == "tgz")
			this->type = TGZ;
		else if(this->fext == "gz")
			if(this->findTar())
				this->type = TGZ;
			else
				this->type = GZ;
		else if(this->fext == "bz2")
			if(this->findTar())
				this->type = TBZ2;
			else
				this->type = BZ2;
		else if(this->fext == "rar")
			this->type = RAR;
		else if(this->fext == "tar")
			this->type = TAR;
		else
			this->type = UNK;
	}

	bool findTar() {
		int tmp = this->fname.find_last_of(".",this->flo-1);
		if(this->fname.substr(tmp+1,this->flo-5) == "tar")
			return true;
		else
			return false;
	}
	
	void Gz() {
		cout << " -> gz";
		this->command = "gunzip < "+this->fname;
		return;
	}

	void Bz2() {
		cout << " -> bz2";
		this->command = "bunzip2 < "+this->fname;
		return;
	}
	
	void TarGz() {
		this->Gz();
		this->fname = this->fname.substr(0,this->fname.find_last_of("."));
		this->command = this->command+" | ";
		this->Tar();
		return;
	}

	void TarBz2() {
		this->Bz2();
		this->fname = this->fname.substr(0,this->fname.find_last_of("."));
		this->command = this->command+" | ";
		this->Tar();
		return;
	}
	
	void Rar() {
		cout << " -> rar";
		this->command = "rar l "+this->fname;
		return;
	}

	void Tar() {
		cout << " -> tar";
		if(this->command != "")
			this->command = this->command+"tar -tvf -";
		else
			this->command = "tar -tvf "+this->fname;
		return;
	}

public:
	Peek() {
		// empty
	}

	Peek(string file) {
		this->File(file);
	}

	string File() {
		return this->fname;
	}

	void File(string file) {
		this->fname = file;
		this->flo = file.find_last_of(".");
		this->fext = file.substr(this->flo+1);
		this->command = "";
		this->Process();
	}

	void Show() {
		switch(this->type) {
			case TGZ:
				this->TarGz();
				break;
			case GZ:
				this->Gz();
				break;
			case TBZ2:
				this->TarBz2();
				break;
			case BZ2:
				this->Bz2();
				break;
			case RAR:
				this->Rar();
				break;
			case TAR:
				this->Tar();
				break;
			case UNK:
			default:
				cerr << PROGNAME << ": Unknown file type: " << this->fname << endl;
				return;
				break;
		}
		system(this->command.c_str());
	}
};

int main(int argc, char *argv[]) {
	PROGNAME = argv[0];
	
	int i;
	string cur;
	Peek *peek = new Peek();
	
	/* requires at least one file name */
	if(argc < 2) {
		cerr << "usage: " << PROGNAME << " <file>" << endl;
		return 1;
	}

	for(i = 1; i < argc; i++) {
		cout << "Processing " << argv[i];
		peek->File(argv[i]);
		peek->Show();
		cout << endl;
	}

	return 0;
}
